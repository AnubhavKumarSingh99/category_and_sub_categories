<ul>
<?php $__currentLoopData = $childs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<li>
    
	    <?php echo e($child->catergoies_name); ?>

      	<?php if(count($child->childs)): ?>
            <?php echo $__env->make('sub_categories',['childs' => $child->childs], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
	</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul><?php /**PATH /var/www/html/Assignment/resources/views/sub_categories.blade.php ENDPATH**/ ?>