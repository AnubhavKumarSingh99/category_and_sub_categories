<!DOCTYPE html>
<html>

<head>
  <title>Laravel Category Treeview Example</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" />
  <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <link href="/css/treeview.css" rel="stylesheet">
</head>

<body>
  <div class="container">
    <div class="panel panel-primary">
      <div class="panel-heading"> Category and Sub-category </div>
      <div class="panel-body">
        <div class="row">
          <div class="col-md-6">
            <h3>Category Tree View</h3>
            <ul id="tree1">
              <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li>
                <?php echo e($category->catergoies_name); ?>

                <?php if(count($category->childs)): ?>
                <?php echo $__env->make('sub_categories',['childs' => $category->childs], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
              </li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </div>
          <div class="col-md-6">
            <h3>Add New Category</h3>



            <form method="post" action="<?php echo e(route('add.category')); ?>">
              <?php echo csrf_field(); ?>

              <?php if($message = Session::get('success')): ?>
              <div class="alert alert-success alert-block">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <strong><?php echo e($message); ?></strong>
              </div>
              <?php endif; ?>

              <div class="form-group">
                <label class="control-label">Category*</label>
                <input type="text" placeholder="Catergory" class="form-control <?php $__errorArgs = ['catergory'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="catergory" value="<?php echo e(old('catergory')); ?>" required>

              </div>

              <div class="form-group">
                <label class="control-label">Sub Category*</label>

                <select class="form-control" name="sub_category">
                  <option value="">Select Category*</option>
                  <?php $__currentLoopData = $allCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singleCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($singleCategory->id); ?>"><?php echo e($singleCategory->catergoies_name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>


              <div class="form-group">
                <button class="btn btn-success">Add New</button>
              </div>

            </form>



          </div>
        </div>


      </div>
    </div>
  </div>

</body>

</html><?php /**PATH /var/www/html/Assignment/resources/views/index.blade.php ENDPATH**/ ?>