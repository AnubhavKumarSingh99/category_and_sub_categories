<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Category;

class CategoryController extends Controller
{
    public function index()
    {



        $categories = Category::where('parent_id', '=', 0)->get();
        $allCategories = Category::all();

        return view('index', compact('categories', 'allCategories'));
    }

    public function addCategory(Request $request)
    {
        $this->validate($request, [
            'catergory' => 'required',
        ]);

        Category::create([
            "catergoies_name" => $request->catergory,
            "parent_id" => ($request->sub_category != null) ? $request->sub_category : 0,
        ]);
        return back()->with('success', 'New Category added successfully.');
    }
}
