<ul>
@foreach($childs as $child)
	<li>
    
	    {{ $child->catergoies_name }}
      	@if(count($child->childs))
            @include('sub_categories',['childs' => $child->childs])
        @endif
	</li>
@endforeach
</ul>