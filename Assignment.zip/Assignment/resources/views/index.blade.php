<!DOCTYPE html>
<html>

<head>
  <title>Laravel Category Treeview Example</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" />
  <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <link href="/css/treeview.css" rel="stylesheet">
</head>

<body>
  <div class="container">
    <div class="panel panel-primary">
      <div class="panel-heading"> Category and Sub-category </div>
      <div class="panel-body">
        <div class="row">
          <div class="col-md-6">
            <h3>Category Tree View</h3>
            <ul id="tree1">
              @foreach($categories as $category)
              <li>
                {{ $category->catergoies_name}}
                @if(count($category->childs))
                @include('sub_categories',['childs' => $category->childs])
                @endif
              </li>
              @endforeach
            </ul>
          </div>
          <div class="col-md-6">
            <h3>Add New Category</h3>



            <form method="post" action="{{route('add.category')}}">
              @csrf

              @if ($message = Session::get('success'))
              <div class="alert alert-success alert-block">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <strong>{{ $message }}</strong>
              </div>
              @endif

              <div class="form-group">
                <label class="control-label">Category*</label>
                <input type="text" placeholder="Catergory" class="form-control @error('catergory') is-invalid @enderror" name="catergory" value="{{old('catergory')}}" required>

              </div>

              <div class="form-group">
                <label class="control-label">Sub Category*</label>

                <select class="form-control" name="sub_category">
                  <option value="">Select Category*</option>
                  @foreach($allCategories as $singleCategory)
                  <option value="{{$singleCategory->id}}">{{$singleCategory->catergoies_name}}</option>
                  @endforeach
                </select>
              </div>


              <div class="form-group">
                <button class="btn btn-success">Add New</button>
              </div>

            </form>



          </div>
        </div>


      </div>
    </div>
  </div>

</body>

</html>