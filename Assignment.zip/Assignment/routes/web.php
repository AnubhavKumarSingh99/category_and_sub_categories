<?php

use App\Category;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Route;



Route::get('/','CategoryController@index');
Route::post('add-category','CategoryController@addCategory')->name('add.category');

